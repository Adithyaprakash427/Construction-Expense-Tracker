import joblib
import numpy as np

model = joblib.load("cost_estimation_model.pkl")
label_encoder = joblib.load("policy_reason_encoder.pkl")

def predict_costs(total_estimate):
    total_estimate = np.array([[total_estimate]])  
    prediction = model.predict(total_estimate)[0]  

    predicted_policy_reason = label_encoder.inverse_transform([int(prediction[4])])[0]

    result = {
        "Material_Cost": prediction[0],
        "Labor_Cost": prediction[1],
        "Profit_Rate": prediction[2],
        "Discount_or_Markup": prediction[3],
        "Policy_Reason": predicted_policy_reason
    }
    
    return result

total_estimate_input = float(input("Enter Total_Estimate: "))
prediction_result = predict_costs(total_estimate_input)

print("\nPredicted Values:")
for key, value in prediction_result.items():
    print(f"{key}: {value}")
