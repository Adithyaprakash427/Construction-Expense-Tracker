import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder

df = pd.read_csv("dataset.csv")

label_encoder = LabelEncoder()
df["Policy_Reason_Encoded"] = label_encoder.fit_transform(df["Policy_Reason"])

X = df[["Total_Estimate"]]
y = df[["Material_Cost", "Labor_Cost", "Profit_Rate", "Discount_or_Markup", "Policy_Reason_Encoded"]]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

joblib.dump(model, "cost_estimation_model.pkl")
joblib.dump(label_encoder, "policy_reason_encoder.pkl")

print("Training complete. Model saved as 'cost_estimation_model.pkl'.")
