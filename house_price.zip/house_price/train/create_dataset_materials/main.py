import pandas as pd
import random

items = [
    {"name": "Cement", "unit_price": 5000, "unit": "bag"},
    {"name": "Bricks", "unit_price": 10, "unit": "brick"},
    {"name": "Steel", "unit_price": 200, "unit": "kg"},
    {"name": "Concrete", "unit_price": 400, "unit": "m3"},
    {"name": "Labor", "unit_price": 1000, "unit": "hour"},
    {"name": "Paint", "unit_price": 200, "unit": "liter"},
    {"name": "Wood", "unit_price": 150, "unit": "board"},
    {"name": "Tiles", "unit_price": 300, "unit": "tile"}
]

def generate_construction_dataset(num_rows=60000):
    data = []
    for i in range(num_rows):
        item = random.choice(items)
        
        quantity = random.randint(1, 100)
        
        material_cost = item["unit_price"] * quantity
        
        row = {
            "SI Number": i + 1,
            "Construction Item": item["name"],
            "Unit": item["unit"],
            "Unit Price (₹)": item["unit_price"],
            "Quantity": quantity,
            "Material Cost (₹)": material_cost
        }
        
        data.append(row)
    df = pd.DataFrame(data)
    
    return df

df = generate_construction_dataset()
df.to_csv('construction_items_dataset.csv', index=False)
print(df.head())
