import pandas as pd
import joblib
from sklearn.tree import DecisionTreeRegressor

df = pd.read_csv("construction_items_dataset.csv")

X = df[['Unit Price (₹)']]  
y = df[['Quantity']]  

model = DecisionTreeRegressor()
model.fit(X, y)

joblib.dump(model, "construction_model.pkl")
print("Model trained and saved as construction_model.pkl")
