import pandas as pd
import joblib
import numpy as np

df = pd.read_csv("construction_items_dataset.csv")

budget = float(input("Enter your budget (₹): "))

df["Predicted Quantity"] = np.floor(budget / df["Unit Price (₹)"]).astype(int)

df = df[df["Predicted Quantity"] > 0]

df = df.drop_duplicates(subset=["Construction Item"], keep="first")

if not df.empty:
    print("\n✅ Materials you can afford:")
    print(df[["Construction Item", "Predicted Quantity"]])
else:
    print("\n❌ Your budget is too low to buy anything.")
