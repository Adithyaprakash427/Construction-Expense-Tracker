import cv2
import numpy as np


image = cv2.imread('a.png')
if image is None:
    print("Error: Could not read the image. Check file path.")
    exit()


hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)


lower_blue = np.array([90, 50, 50])  
upper_blue = np.array([130, 255, 255])  

blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)
white_mask = cv2.inRange(image, np.array([200, 200, 200]), np.array([255, 255, 255]))

blue_area_pixels = cv2.countNonZero(blue_mask)
white_area_pixels = cv2.countNonZero(white_mask)
total_area_pixels = image.shape[0] * image.shape[1]

blue_ratio = blue_area_pixels / total_area_pixels
white_ratio = white_area_pixels / total_area_pixels

total_sqft = 1000  
blue_sqft = blue_ratio * total_sqft

cost_per_sqft = 2780  
total_cost = blue_sqft * cost_per_sqft

print(f"Blue Area: {blue_ratio * 100:.2f}% ({blue_sqft:.2f} sq ft)")
print(f"White Area: {white_ratio * 100:.2f}%")
print(f"Estimated Construction Cost: ₹{total_cost:,.2f}")

cv2.imshow('Blue Mask', blue_mask)
cv2.imshow('White Mask', white_mask)
cv2.imshow('Original', image)
cv2.waitKey(0)
cv2.destroyAllWindows()
