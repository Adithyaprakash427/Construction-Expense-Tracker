import joblib
import pandas as pd
from datetime import datetime

model = joblib.load("best_model.pkl")
label_encoders = joblib.load("label_encoders.pkl")

print("Available BUILDTYPE categories:", label_encoders['BUILDTYPE'].classes_)

def safe_transform(encoder, value):
    """Transforms value if it exists, else assigns a default (first category)."""
    if value in encoder.classes_:
        return encoder.transform([value])[0]
    else:
        print(f"Warning: '{value}' not found, using default '{encoder.classes_[0]}'")
        return encoder.transform([encoder.classes_[0]])[0]  

data_input = {
    'AREA': safe_transform(label_encoders['AREA'], 'Karapakkam'),
    'INT_SQFT': 1250.0,
    'N_BEDROOM': 3,
    'N_BATHROOM': 2,
    'N_ROOM': 5,
    'BUILDTYPE': safe_transform(label_encoders['BUILDTYPE'], 'Individual House'),
    'PARK_FACIL': safe_transform(label_encoders['PARK_FACIL'], 'Yes'),
    'QS_ROOMS': 4.0,
    'QS_BATHROOM': 3.5,
    'QS_BEDROOM': 4.0,
    'QS_OVERALL': 3.8,
    'REG_FEE': 50000.0,
    'COMMIS': 25000.0,
    'SALE_YEAR': 2023,
    'BUILD_YEAR': 2018,
    'SALE_MONTH': 7,
    'BUILD_AGE': datetime.now().year - 2018,
    'DIST_MAINROAD': 2.5
}

expected_features = list(model.feature_names_in_)
df_input = pd.DataFrame([data_input], columns=expected_features)

print("Input DataFrame:\n", df_input)

try:
    prediction = model.predict(df_input)[0]
    print("Predicted Price:", round(prediction, 2))
except Exception as e:
    print("Error:", str(e))
