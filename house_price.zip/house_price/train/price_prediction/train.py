import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Lasso, Ridge
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib
import time

file_path = r"preprocessed_house_data.csv"
house_data = pd.read_csv(file_path)

selected_features = [
    'REG_FEE', 'AREA', 'INT_SQFT', 'BUILDTYPE', 'N_BEDROOM', 'N_BATHROOM',
    'COMMIS', 'DIST_MAINROAD', 'QS_OVERALL', 'QS_ROOMS', 'QS_BATHROOM',
    'PARK_FACIL', 'QS_BEDROOM', 'SALE_YEAR', 'BUILD_YEAR', 'BUILD_AGE',
    'SALE_MONTH', 'N_ROOM'
]
X = house_data[selected_features]
y = house_data['SALES_PRICE']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

models = {
    'RandomForest': RandomForestRegressor(),
    'Lasso': Lasso(),
    'Ridge': Ridge()
}

param_grids = {
    'RandomForest': {
        'n_estimators': [100, 200],
        'max_depth': [None, 10, 20],
        'min_samples_split': [2, 5, 10]
    },
    'Lasso': {
        'alpha': [0.01, 0.1, 1, 10]
    },
    'Ridge': {
        'alpha': [0.01, 0.1, 1, 10]
    }
}

best_models = {}
training_times = {}
prediction_times = {}

for model_name, model in models.items():
    print(f"Training {model_name}...")
    
    start_train_time = time.time()
    grid_search = GridSearchCV(model, param_grids[model_name], cv=5, scoring='neg_mean_squared_error')
    grid_search.fit(X_train, y_train)
    best_models[model_name] = grid_search.best_estimator_
    end_train_time = time.time()
    
    training_time = end_train_time - start_train_time
    training_times[model_name] = training_time
    
    start_pred_time = time.time()
    y_pred = best_models[model_name].predict(X_test)
    end_pred_time = time.time()
    
    prediction_time = end_pred_time - start_pred_time
    prediction_times[model_name] = prediction_time
    
    mse = mean_squared_error(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    
    print(f"{model_name} MSE: {mse}")
    print(f"{model_name} MAE: {mae}")
    print(f"{model_name} R²: {r2}")
    print(f"{model_name} Training Time: {training_time:.4f} seconds")
    print(f"{model_name} Prediction Time: {prediction_time:.4f} seconds")

best_model = best_models['RandomForest']
model_file_path = r"best_model.pkl"
joblib.dump(best_model, model_file_path)

print("Best model is saved.")
