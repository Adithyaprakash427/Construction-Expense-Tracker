from django.shortcuts import render
from django.http import JsonResponse
import joblib
import pandas as pd
import numpy as np
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
import json
import cv2
from django.conf import settings
import os
import numpy as np

def calculate_blue_area_cost(filename, cost_per_sqft=2000):
    image = cv2.imread(filename)
    if image is None:
        return "Error: Unable to read image."

    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    
    lower_blue = np.array([90, 130, 50])
    upper_blue = np.array([130, 255, 255])
    mask = cv2.inRange(hsv, lower_blue, upper_blue)

    blue_area_pixels = np.sum(mask > 0)
    
    KNOWN_IMAGE_WIDTH = 1000
    KNOWN_IMAGE_HEIGHT = 1000
    KNOWN_IMAGE_AREA_SQFT = 10
    pixels_per_sqft = (KNOWN_IMAGE_WIDTH * KNOWN_IMAGE_HEIGHT) / KNOWN_IMAGE_AREA_SQFT
    
    blue_area_sqft = blue_area_pixels / pixels_per_sqft

    adjustment_factor = 1 + (blue_area_pixels / (image.shape[0] * image.shape[1]))
    total_cost = blue_area_sqft * cost_per_sqft * adjustment_factor

    return round(total_cost, 2)



house_price_model = joblib.load("best_model.pkl")  
house_label_encoders = joblib.load("label_encoders.pkl")  

cost_estimation_model = joblib.load("cost_estimation_model.pkl")  
policy_label_encoder = joblib.load("policy_reason_encoder.pkl")  

material_cost_model = joblib.load("construction_material_predictor_model.pkl")
material_label_encoder = joblib.load("label_encoder.pkl")

expected_features = [
    'AREA', 'INT_SQFT', 'N_BEDROOM', 'N_BATHROOM', 'N_ROOM', 'BUILDTYPE', 'PARK_FACIL',
    'QS_ROOMS', 'QS_BATHROOM', 'QS_BEDROOM', 'QS_OVERALL', 'REG_FEE', 'COMMIS',
    'SALE_YEAR', 'BUILD_YEAR', 'SALE_MONTH', 'BUILD_AGE', 'DIST_MAINROAD'
]

def predict_costs(total_estimate):
    total_estimate = np.array([[total_estimate]])  
    
    total_estimate = total_estimate * (1 + np.random.uniform(-0.05, 0.05))  

    prediction = cost_estimation_model.predict(total_estimate)[0]  

    predicted_policy_reason = policy_label_encoder.inverse_transform([int(prediction[4])])[0]

    variation_factor = np.random.uniform(0.95, 1.05)  

    result = {
        "Material_Cost": round(prediction[0] * 80 * variation_factor, 2),
        "Labor_Cost": round(prediction[1] * 80 * variation_factor, 2),
        "Profit_Rate": round(prediction[2] * 80 * variation_factor, 2),
        "Discount_or_Markup": round(prediction[3] * 80 * variation_factor, 2),
        "Policy_Reason": predicted_policy_reason
    }
    
    return result

def predict_material_and_price(material_cost):
    material_cost_input = np.array([[0, 0, material_cost]])
    predicted_cost = material_cost_model.predict(material_cost_input)[0]
    return predicted_cost

def home(request):
    return render(request, 'index.html')

def dash(request):
    return render(request, 'dash.html')

def get_affordable_materials(budget, dataset_path="construction_items_dataset.csv"):
    df = pd.read_csv(dataset_path)
    df["Predicted Quantity"] = np.floor(budget / df["Unit Price (₹)"]).astype(int)
    df = df[df["Predicted Quantity"] > 0]
    df = df.drop_duplicates(subset=["Construction Item"], keep="first")
    result = df.set_index("Construction Item")["Predicted Quantity"].to_dict()
    return result

@csrf_exempt
def predict(request):
    if request.method == 'POST':
        try:
            def safe_transform(encoder, value):
                if value in encoder.classes_:
                    return encoder.transform([value])[0]
                else:
                    print(f"Warning: '{value}' not found, using default '{encoder.classes_[0]}'")
                    return encoder.transform([encoder.classes_[0]])[0]

            build_year = int(request.POST.get('build_year', 2018))

            if build_year > 2000:
                bias_factor = 1 + (0.0005 * (build_year - 2000))   
            else:
                bias_factor = max(0.1, 1 - (0.0003 * (2000 - build_year)))  

            data_input = {
                'AREA': safe_transform(house_label_encoders['AREA'], request.POST.get('area', 'Karapakkam')),
                'INT_SQFT': float(request.POST.get('int_sqft', 1250.0)),
                'N_BEDROOM': int(request.POST.get('n_bedroom', 3)),
                'N_BATHROOM': int(request.POST.get('n_bathroom', 2)),
                'N_ROOM': int(request.POST.get('n_room', 5)),
                'BUILDTYPE': safe_transform(house_label_encoders['BUILDTYPE'], request.POST.get('build_type', 'Individual House')),
                'PARK_FACIL': safe_transform(house_label_encoders['PARK_FACIL'], request.POST.get('park_facil', 'Yes')),
                'QS_ROOMS': float(request.POST.get('qs_rooms', 4.0)),
                'QS_BATHROOM': float(request.POST.get('qs_bathroom', 3.5)),
                'QS_BEDROOM': float(request.POST.get('qs_bedroom', 4.0)),
                'QS_OVERALL': float(request.POST.get('qs_overall', 3.8)),
                'REG_FEE': float(request.POST.get('reg_fee', 50000.0)),
                'COMMIS': float(request.POST.get('commis', 25000.0)),
                'SALE_YEAR': int(request.POST.get('sale_year', 2023)),
                'BUILD_YEAR': build_year,
                'SALE_MONTH': int(request.POST.get('sale_month', 7)),
                'BUILD_AGE': datetime.now().year - build_year,
                'DIST_MAINROAD': float(request.POST.get('dist_mainroad', 2.5))
            }

            df_input = pd.DataFrame([data_input], columns=house_price_model.feature_names_in_)

            house_price_prediction = house_price_model.predict(df_input)[0]
            adjusted_price = round(house_price_prediction * bias_factor, 2)

            raw_cost_breakdown = predict_costs(adjusted_price)
            cost_breakdown = {
                'Material_Cost': round(raw_cost_breakdown["Material_Cost"] * bias_factor, 2),
                'Labor_Cost': round(raw_cost_breakdown["Labor_Cost"] * bias_factor, 2),
                'Total_Cost': round((raw_cost_breakdown["Material_Cost"] + raw_cost_breakdown["Labor_Cost"]) * bias_factor, 2)
            }


            material_cost_prediction = get_affordable_materials(cost_breakdown["Material_Cost"])

            response_data = {
                'predicted_price': adjusted_price,
                'cost_breakdown': cost_breakdown,
                'material_cost_prediction': material_cost_prediction
            }
            print(response_data)
            return JsonResponse(response_data)

        except Exception as e:
            return JsonResponse({'error': str(e)})
@csrf_exempt
def upload_image(request):
    if request.method == "POST" and request.FILES.get("image"):
        image = request.FILES["image"]

        static_dir = settings.STATICFILES_DIRS[0] if settings.STATICFILES_DIRS else os.path.join(settings.BASE_DIR, "static")

        upload_dir = os.path.join(static_dir, "uploads")
        os.makedirs(upload_dir, exist_ok=True)

        file_path = os.path.join(upload_dir, image.name)
        with open(file_path, "wb") as f:
            for chunk in image.chunks():
                f.write(chunk)
        x=calculate_blue_area_cost(upload_dir+"\\"+image.name)

        r = predict_costs(x)
        cost_breakdown = {
            'Material_Cost': round(r["Material_Cost"]),
            'Labor_Cost': round(r["Labor_Cost"]),
            'Total_Cost': round((r["Material_Cost"] + r["Labor_Cost"]))
        }


        material_cost_prediction = get_affordable_materials(cost_breakdown["Material_Cost"])

        response_data = {
            'predicted_price': x,
            'cost_breakdown': cost_breakdown,
            'material_cost_prediction': material_cost_prediction
        }
        print(response_data)
        return JsonResponse(response_data)


    return JsonResponse({"success": False, "error": "No image uploaded."})